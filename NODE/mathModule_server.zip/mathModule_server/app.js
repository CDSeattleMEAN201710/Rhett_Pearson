var mathlib = require('./mathlib')();
mathlib.add(1,2)
mathlib.multiply(1,2)
mathlib.square(2)
mathlib.random(2,24)
